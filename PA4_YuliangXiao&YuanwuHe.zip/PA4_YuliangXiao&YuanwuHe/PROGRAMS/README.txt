Programming Assignment 4 -- Yuliang Xiao & Yuanwu He

Source Files:
1. FindClosestPoint.m: Find closest point in the triangle.
2. FrameHomo.m: Homogeneous representation of frame F.
3. FrameTrans.m: 3D frame transformaton.
4. InvF.m: compute inverse of frame (R, p).
5. PA4.m: executable file for PA3.
6. ProjectOnSegment.m: Project on segment to find closest point on the boarder of the triangle.
7. T2TR.m: 3D to 3D registration algorithm.
8. TriDxform.m: 3D points transformaton.
9. ComputeCenters.m: compute center of the bounding sphere of each triangle.
10. ComputeVars.m: obtain radius and centers of the bounding sphere of each triangle.


Instruction for runnning the program:

1. Open the MATLAB and add the PROGRAMS folder, its subfolder and datatset folder to the path
2. Run the PA3.m to operate the program.
3. The result is stored in the OUTPUTS folder.
