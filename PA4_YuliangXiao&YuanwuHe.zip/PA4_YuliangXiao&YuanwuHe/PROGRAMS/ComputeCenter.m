% Compute center of the bounding sphere formed by the triangle
% { compute cenetr of the bounding sphere
%   Input: xyz coordinate of three vertexes of the triangle
%   Output: xyz coordinate of center of bounding sphere
% }
function c = ComputeCenter(a, b, c)
    % copmute mid-point of longest edge of triangle
    f = (a + b) / 2;
    u = a - f;
    v = c - f;
    d = cross(cross(u,v), u);
    % compute coefficient gamma to obtain center of bounding sphere
    gamma = (norm(v)^2 - norm(u)^2) ./ (2 * d * (v - u)');
    if (gamma <= 0)
        lambda = 0;
    else
        lambda = gamma;
    end
    c = f + lambda .* d;
end