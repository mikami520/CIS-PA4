clear all
clc
debug = ['A','B','C','D','E','F'];
unknown = ['G','H','J','K'];
mkdir('OUTPUTS');
% create OUTPUTS folder
% iterate all testing files
for i=1:length(debug)
    k = 'Debug';
    x = debug(i);
    main(x, k);
end

for j = 1:length(unknown)
    k = 'Unknown';
    x = unknown(j);
    main(x, k);
end
function [cs, distances, as] = main(xx,kk)
    %%% read mesh file
    bodySur = importdata('Problem4MeshFile.sur');
    nVertices = bodySur(1);
    nTriangles = bodySur(2+nVertices*3);
    dVertices = bodySur(2:1+nVertices*3);
    dTriangles = bodySur(3+nVertices*3:size(bodySur,1));
    data_V = [];
    data_T = [];
    en = 0;
    % adjust input file to get xyz coordinate of vertex in CT coordinates
    for i=1:nVertices
        start = en + 1;
        en = i * 3;
        data = (dVertices(start:en))';
        data_V = [data_V; data];
    end
    % adjust input file to get Vertex indices of the three vertices for each triangle, followed by triangle indices for the three neighbor triangles.opposite to the three vertices
    en1 = 0;
    for i=1:nTriangles
        start1 = en1 + 1;
        en1 = i * 6;
        data1 = (dTriangles(start1:en1))';
        data_T = [data_T; data1];
    end

    %%% read body frame A
    bodyA = importdata('Problem4-BodyA.txt');
    nMarkers_A = str2double(bodyA.textdata{1}(1));
    data_A = bodyA.data;
    data_Marker_A = data_A(1:nMarkers_A,:);
    Ptip_A = data_A(nMarkers_A + 1,:);

    %%% read body frame B
    bodyB = importdata('Problem4-BodyB.txt');
    nMarkers_B = str2double(bodyB.textdata{1}(1));
    data_B = bodyB.data;
    data_Marker_B = data_B(1:nMarkers_B,:);
    Ptip_B = data_B(nMarkers_B + 1,:);

    %%% read sample frame
    filename1 = ['PA4-',xx,'-',kk,'-SampleReadingsTest.txt'];
    sampleF = importdata(filename1);
    data_F = sampleF.data;
    nSample = str2double(sampleF.textdata{1});
    nFrame = str2double(sampleF.textdata{2});
    en = 0;
    Fas = cell(nFrame,1);
    Fbs = cell(nFrame,1);
    dks = [];
    % for each frame, read ak and bk to compute FAk and FBk by using 3D to 3D registration
    for i = 1:nFrame
        en = nSample*(i-1);
        start = en + 1;
        en = en + nMarkers_A;
        data_a = data_F(start:en,:);
        data_b = data_F(en+1:en+nMarkers_B, :);
        data_d = data_F(en+nMarkers_B + 1 : nSample*i,:);
        Fa = T2TR(data_Marker_A, data_a);
        Fb = T2TR(data_Marker_B, data_b);
        Fas{i} = Fa;
        Fbs{i} = Fb;
        [~,~,invFb] = InvF(Fb);
        [~,~,FrameTr] = FrameTrans(invFb, Fa);
        [~, dk] = TriDxform(FrameTr, Ptip_A');
        dks = [dks;dk'];
    end


    % find all data point of three vertex of each triangle
    ind_p = data_T(:,1) + 1;
    ind_q = data_T(:,2) + 1;
    ind_r = data_T(:,3) + 1;

    p = [];
    q = [];
    r = [];
    for i = 1:size(data_T, 1)
        p = [p; data_V(ind_p(i),:)];
        q = [q; data_V(ind_q(i),:)];
        r = [r; data_V(ind_r(i),:)];
    end
    % define maximum iteration
    MaxIteration = 80;
    % give an initial guess for Freg
    Freg = FrameHomo(eye(3), zeros(3,1));
    % compute parameters for each triangle
    [center, radius] = ComputeVars(p, q, r);
    for i = 1:MaxIteration
        % get sample points
        [~, sks] = TriDxform(Freg, dks);
        cs = [];
        distances = [];
        % iterate sample points
        for j = 1:length(sks)
            a = sks(j,:);
            % initialize boundary
            bound = Inf;
            % iterate each triangle
            for k = 1:length(p)
                qi = q(k,:);
                pi = p(k,:);
                ri = r(k,:);
                % check if the point is within the bounding sphere
                if (norm(center(k,:) - a) - radius(k) <= bound)
                    % find closest point h and minimal distance
                    [h, distance] = FindClosestPoint(a, pi, qi, ri);
                    % update the closest point and minimal distance if the distance is less than boundary
                    if (norm(h - a) < bound)
                        c = h;
                        dist = distance;
                        bound = norm(h - a);
                    end
                end
            end
            % collect all closest points and minimal distances
            cs = [cs;c];
            distances = [distances;dist];
        end
        % use 3D to 3D registration to make a new estimation of Freg
        Freg = T2TR(dks, cs);
    end
    
    %%% Export data
    FULLDATA = [sks'; cs'; distances'];
    file_name = ['./OUTPUTS/PA4-Generated-',xx,'-',kk,'-Output.txt'];
    file_name1 = [' PA4-Generated-',xx,'-',kk,'-Output.txt 0'];
    fileID = fopen(file_name,'wt+');
    fprintf(fileID,strcat(num2str(nFrame), file_name1, '\n'));
    fprintf(fileID,'%10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',FULLDATA);
    fclose(fileID);
end