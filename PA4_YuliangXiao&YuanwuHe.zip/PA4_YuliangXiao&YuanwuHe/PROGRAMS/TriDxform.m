% { 3D points transformaton
%   Input: frame F, 3D point b
%   Output: RotVec: position of 3D point with only rotation
%           RotTransVec: position of 3D point with frame transformation
% }
function [RotVec, RotTransVec] = TriDxform(F, b)
    R = F(1:3, 1:3);
    p = F(1:3, 4);
    if size(b,2) == 1
        RotVec = R * b;
        RotTransVec = R * b + p;
    else
        RotVec = [];
        RotTransVec = [];
        for i = 1:size(b,1)
            b1 = b(i,:)';
            RotVec = [RotVec; (R * b1)'];
            RotTransVec = [RotTransVec; (R * b1 + p)'];
        end
    end
end