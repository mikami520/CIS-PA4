% Compute parameters of bounding sphere formed by each triangle
% { Compute parameters of bounding sphere
%   Input: xyz coordinate of three vertexes of the triangle
%   Output: center and radius of bounding sphere
% }
function [center, radius] = ComputeVars(p, q, r)
    % define necessary variables
    radius = [];
    center = [];
    % iterate each triangle to find bounding sphere parameters
    for i = 1:length(p)
        % compute three edges of triangle
		edge1 = norm(p(i,:) - q(i,:));
		edge2 = norm(p(i,:) - r(i,:));
		edge3 = norm(r(i,:) - q(i,:));
        % find longest edge
		maxEdge = max([edge1, edge2, edge3]);
        % check if the longest edge is the diameter (this is the right triangle)
        if (maxEdge == edge1)
            % right triangle, radius is 1/2 longest edge and center is the mid-point of longest edge
            if (edge1^2 == edge2^2 + edge3^2)
                radius = [radius; edge1/2];
                c = (p(i,:) + q(i,:)) / 2;
                center = [center; c];
            else
                % call compute center function to find center and radius is the distance between center and any triangle vertex
                c = ComputeCenter(p(i,:), q(i,:), r(i,:));
                radius = [radius; norm(c - p(i,:))];
                center = [center; c];
            end
        elseif (maxEdge == edge2)
            % right triangle, radius is 1/2 longest edge and center is the mid-point of longest edge
            if (edge2^2 == edge1^2 + edge3^2)
                radius = [radius; edge2/2];
                c = (p(i,:) + r(i,:)) / 2;
                center = [center; c];
            else
                % call compute center function to find center and radius is the distance between center and any triangle vertex
                c = ComputeCenter(p(i,:), r(i,:), q(i,:));
                radius = [radius; norm(c - p(i,:))];
                center = [center; c];
            end
        elseif (maxEdge == edge3)
             % right triangle, radius is 1/2 longest edge and center is the mid-point of longest edge
            if (edge3^2 == edge2^2 + edge1^2)
                radius = [radius; edge3/2];
                c = (r(i,:) + q(i,:)) / 2;
                center = [center; c];
            else
                % call compute center function to find center and radius is the distance between center and any triangle vertex
                c = ComputeCenter(r(i,:), q(i,:), p(i,:));
                radius = [radius; norm(c - r(i,:))];
                center = [center; c];
            end
        end
    end
end