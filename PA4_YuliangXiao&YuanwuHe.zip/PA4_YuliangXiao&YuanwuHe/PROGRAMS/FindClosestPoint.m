% Find closest point in the triangle
% { find closest point in the triangle
%   Input: dataset a, xyz coordinate of three vertexes of the triangle
%   Output: cloest point c_outputs with Nsample frame and corresonding minimal distance between a and c_outputs
% }
function  [c_output, distance] = FindClosestPoint(a, p, q, r)
        % for each triangle, compute coefficient using least squares
        B = (a - p)';
        A = [(q - p)', (r - p)'];
        res = lsqr(A,B);
        lambda = res(1);
        mu = res(2);
        % calculate a temporary closest point c
        c = lambda * (q - p) + mu * (r - p) + p;
        % check if c lies within the triangle
        % if not, we need to find point on the boarder of the triangle
        if (lambda < 0)
            c_output = ProjectOnSegment(c,r,p);
        elseif (mu < 0)
            c_output = ProjectOnSegment(c,p,q);
        elseif (lambda + mu > 1)
            c_output = ProjectOnSegment(c,q,r);
        else
            c_output = c;
        end
        % copmute distance between result point and input point
        distance = norm(c_output - a);
end