% { Project on segment
%   Input: three data point noted x, y, z
%   Output: corrected closest point c
% }
function c = ProjectOnSegment(x,y,z)
    lambda = ((x-y).*(z-y)) ./ ((z-y) .* (z-y));
    lambda_seg = max(0, min(lambda,1));
    c = y + lambda_seg .* (z-y);
end